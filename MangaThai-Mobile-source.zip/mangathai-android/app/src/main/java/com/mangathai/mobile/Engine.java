package com.mangathai.mobile;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** OCR + English to Thai translation, entirely on the phone. */
public final class Engine {
    public interface Status { void show(String text); }

    private static final String CACHE_VERSION = "m1";

    private final File pageDir;
    private final File textCacheFile;
    private final File rulesFile;
    private final TextRecognizer recognizer;
    private final Translator translator;
    private final JSONObject textCache;
    private TextTools.Rules rules;
    private volatile boolean modelReady;
    private boolean textCacheDirty;

    public Engine(Context context) {
        File base = context.getFilesDir();
        pageDir = new File(base, "pages");
        //noinspection ResultOfMethodCallIgnored
        pageDir.mkdirs();
        textCacheFile = new File(base, "translations.json");
        rulesFile = new File(base, "rules.txt");
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        translator = Translation.getClient(new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.THAI)
                .build());
        JSONObject cache;
        try { cache = new JSONObject(read(textCacheFile)); } catch (Exception e) { cache = new JSONObject(); }
        textCache = cache;
        rules = TextTools.Rules.parse(readRules());
    }

    // ---------- rules ----------
    public synchronized String readRules() {
        try { return read(rulesFile); } catch (IOException e) { return ""; }
    }

    public synchronized void saveRules(String text) throws IOException {
        write(rulesFile, text);
        rules = TextTools.Rules.parse(text);
        clearPages(); // pages store final text, rebuild them with the new rules
    }

    public synchronized void clearAll() {
        clearPages();
        Iterator<String> keys = textCache.keys();
        List<String> names = new ArrayList<>();
        while (keys.hasNext()) names.add(keys.next());
        for (String key : names) textCache.remove(key);
        textCacheDirty = true;
        flush();
    }

    private void clearPages() {
        File[] files = pageDir.listFiles();
        if (files != null) for (File f : files) //noinspection ResultOfMethodCallIgnored
            f.delete();
    }

    // ---------- model ----------
    public void ensureModel(Status status) throws Exception {
        if (modelReady) return;
        status.show("ดาวน์โหลดโมเดลแปลภาษาไทยครั้งแรก (~30 MB) ต้องต่ออินเทอร์เน็ต…");
        Tasks.await(translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()), 10, TimeUnit.MINUTES);
        modelReady = true;
        status.show("โมเดลพร้อมแล้ว ต่อจากนี้แปลแบบออฟไลน์ได้");
    }

    // ---------- page ----------
    /** Returns the JSON result for one page image (cached by image content). */
    public String process(byte[] data, Status status) throws Exception {
        String key = sha256(data);
        File cached = new File(pageDir, key + ".json");
        if (cached.exists()) {
            try {
                String text = read(cached);
                if (new JSONObject(text).optString("cache").equals(CACHE_VERSION)) return text;
            } catch (Exception ignored) { /* rebuild */ }
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
        if (bitmap == null) throw new IOException("อ่านไฟล์ภาพไม่ได้");
        try {
            String result = processBitmap(bitmap, key, status);
            write(cached, result);
            return result;
        } finally {
            bitmap.recycle();
        }
    }

    private String processBitmap(Bitmap bitmap, String key, Status status) throws Exception {
        int width = bitmap.getWidth(), height = bitmap.getHeight();
        // Manga lettering is small; ML Kit reads best at ~16-24 px letters.
        float scale = Math.max(1f, Math.min(2.5f, 1600f / Math.max(1, width)));
        Bitmap ocrBitmap = bitmap;
        if (scale > 1.01f) {
            ocrBitmap = Bitmap.createScaledBitmap(bitmap, Math.round(width * scale), Math.round(height * scale), true);
        }
        Text text;
        try {
            text = Tasks.await(recognizer.process(InputImage.fromBitmap(ocrBitmap, 0)), 60, TimeUnit.SECONDS);
        } finally {
            if (ocrBitmap != bitmap) ocrBitmap.recycle();
        }

        List<Grouper.Line> lines = new ArrayList<>();
        int blockIndex = 0;
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                Rect r = line.getBoundingBox();
                if (r == null) continue;
                lines.add(new Grouper.Line(r.left / scale, r.top / scale, r.width() / scale, r.height() / scale,
                        line.getText(), blockIndex));
            }
            blockIndex++;
        }

        List<List<Grouper.Line>> groups = Grouper.group(lines);
        JSONArray bubbles = new JSONArray();
        int index = 0;
        for (List<Grouper.Line> group : groups) {
            index++;
            String source = TextTools.clean(Grouper.joinText(group));
            if (!TextTools.worthTranslating(source)) continue;
            status.show("แปลช่อง " + index + "/" + groups.size());
            String thai = translate(source);
            if (thai.trim().isEmpty()) continue;
            float[] rect = Grouper.bounds(group);
            String[] colors = colors(bitmap, rect);
            JSONObject item = new JSONObject();
            item.put("cover", array(rect));
            item.put("box", array(textBox(rect, width, height)));
            item.put("thai", thai);
            item.put("source", source);
            item.put("font", Math.round(Grouper.medianHeight(group) * 0.9f));
            item.put("background", colors[0]);
            item.put("color", colors[1]);
            bubbles.put(item);
        }
        flush();
        JSONObject result = new JSONObject();
        result.put("cache", CACHE_VERSION);
        result.put("sha256", key);
        result.put("width", width);
        result.put("height", height);
        result.put("bubbles", bubbles);
        return result.toString();
    }

    private String translate(String source) throws Exception {
        TextTools.Rules current;
        synchronized (this) { current = rules; }
        String prepared = current.applyBefore(source);
        String raw;
        synchronized (this) { raw = textCache.optString(prepared, null); }
        if (raw == null) {
            raw = Tasks.await(translator.translate(prepared), 60, TimeUnit.SECONDS);
            synchronized (this) {
                textCache.put(prepared, raw);
                textCacheDirty = true;
            }
        }
        return current.applyAfter(raw).trim();
    }

    private synchronized void flush() {
        if (!textCacheDirty) return;
        try { write(textCacheFile, textCache.toString()); textCacheDirty = false; } catch (IOException ignored) { }
    }

    /** Thai is longer than English: give it a little more room around the English text. */
    private static float[] textBox(float[] r, int width, int height) {
        float growX = r[2] * 0.12f, growY = r[3] * 0.10f;
        float left = Math.max(0, r[0] - growX), top = Math.max(0, r[1] - growY);
        float right = Math.min(width, r[0] + r[2] + growX), bottom = Math.min(height, r[1] + r[3] + growY);
        return new float[]{left, top, right - left, bottom - top};
    }

    /** Paper colour behind the lettering and a readable text colour. */
    private static String[] colors(Bitmap bitmap, float[] r) {
        int x0 = clamp((int) r[0], 0, bitmap.getWidth() - 1), y0 = clamp((int) r[1], 0, bitmap.getHeight() - 1);
        int x1 = clamp((int) (r[0] + r[2]), x0 + 1, bitmap.getWidth()), y1 = clamp((int) (r[1] + r[3]), y0 + 1, bitmap.getHeight());
        int step = Math.max(1, (int) Math.sqrt((x1 - x0) * (double) (y1 - y0) / 2500.0));
        List<int[]> samples = new ArrayList<>();
        for (int y = y0; y < y1; y += step) {
            for (int x = x0; x < x1; x += step) {
                int c = bitmap.getPixel(x, y);
                int red = (c >> 16) & 255, green = (c >> 8) & 255, blue = c & 255;
                samples.add(new int[]{(int) (0.299 * red + 0.587 * green + 0.114 * blue), red, green, blue});
            }
        }
        if (samples.isEmpty()) return new String[]{"#ffffff", "#1f1830"};
        samples.sort((a, b) -> Integer.compare(a[0], b[0]));
        int n = samples.size();
        boolean lightPaper = samples.get(n / 2)[0] > 110;
        List<int[]> chosen = lightPaper ? samples.subList(n * 2 / 5, n) : samples.subList(0, Math.max(1, n / 5));
        int[] red = new int[chosen.size()], green = new int[chosen.size()], blue = new int[chosen.size()];
        for (int i = 0; i < chosen.size(); i++) { red[i] = chosen.get(i)[1]; green[i] = chosen.get(i)[2]; blue[i] = chosen.get(i)[3]; }
        int rr = median(red), gg = median(green), bb = median(blue);
        double luminance = 0.299 * rr + 0.587 * gg + 0.114 * bb;
        return new String[]{String.format("#%02x%02x%02x", rr, gg, bb), luminance > 140 ? "#1f1830" : "#ffffff"};
    }

    public void close() {
        flush();
        recognizer.close();
        translator.close();
    }

    // ---------- small helpers ----------
    private static int median(int[] values) { Arrays.sort(values); return values[values.length / 2]; }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static JSONArray array(float[] values) throws JSONException {
        JSONArray a = new JSONArray();
        for (float v : values) a.put(Math.round(v * 10f) / 10.0);
        return a;
    }

    static String sha256(byte[] data) throws NoSuchAlgorithmException {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder b = new StringBuilder();
        for (byte d : digest) b.append(String.format("%02x", d));
        return b.toString();
    }

    static String read(File file) throws IOException {
        try (InputStream in = new FileInputStream(file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    static void write(File file, String text) throws IOException {
        File temporary = new File(file.getPath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(temporary)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
        if (!temporary.renameTo(file)) {
            //noinspection ResultOfMethodCallIgnored
            file.delete();
            if (!temporary.renameTo(file)) throw new IOException("บันทึกไฟล์ไม่ได้: " + file.getName());
        }
    }
}
